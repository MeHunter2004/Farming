#include "selection.h"
#include "ui_selection.h"
#include <Animal.h>
Selection::Selection(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Selection)
{
    ui->setupUi(this);
}

Selection::~Selection()
{
    delete ui;
}



void Selection::on_cow_pushButton_clicked()
{
    // Cow* cow = new Cow();
    // cow->sound();
    emit cow_pushButtonClicked();

}

